#!/usr/bin/env python3


import prompt
import random
import sys
import cli
sys.path.insert(0, '/home/fyodor/python-project-49/brain_games')


def main():
    cli.welcome_user()
    print ('Answer "yes" if the number is even, otherwise answer "no".')
    print ('Question: ' + str(15))
    answer = prompt.string('Your answer: ' + answer)


if __name__ == '__main__':
    main()
