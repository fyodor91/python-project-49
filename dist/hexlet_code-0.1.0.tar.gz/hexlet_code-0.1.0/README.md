### Hexlet tests and linter status:
[![Actions Status](https://github.com/fyodor91/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/fyodor91/python-project-49/actions)