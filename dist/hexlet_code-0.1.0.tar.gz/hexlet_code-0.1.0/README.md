### Hexlet tests and linter status:
[![Actions Status](https://github.com/fyodor91/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/fyodor91/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/b98262d0795668e85f38/maintainability)](https://codeclimate.com/github/fyodor91/python-project-49/maintainability)
